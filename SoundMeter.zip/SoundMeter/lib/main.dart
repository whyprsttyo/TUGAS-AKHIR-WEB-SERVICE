import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:noise_meter/noise_meter.dart';
import 'package:sqflite/sqflite.dart' show Database, openDatabase;
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import "package:fl_chart/fl_chart.dart" show FlDotData, FlSpot, FlTitlesData, LineChart, LineChartBarData, LineChartData, SideTitles;

void main() {
  runApp(SoundMeterApp());
}

class SoundMeterApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Sound Meter',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: SoundMeterPage(),
    );
  }
}

class SoundMeterPage extends StatefulWidget {
  @override
  _SoundMeterPageState createState() => _SoundMeterPageState();
}

class _SoundMeterPageState extends State<SoundMeterPage> {
  NoiseMeter? _noiseMeter;
  StreamSubscription<NoiseReading>? _noiseSubscription;
  bool _isRecording = false;
  double _currentDecibel = 0.0;
  List<NoiseData> _dataList = [];
  Timer? _autoSaveTimer;
  DatabaseHelper _databaseHelper = DatabaseHelper.instance;

  @override
  void initState() {
    super.initState();
    _noiseMeter = NoiseMeter();

  }

  void onError(Object error) {
    print("NoiseMeter Error: $error");
    _isRecording = false;
  }

  void start() async {
    try {
     soundStream();
      setState(() {
        _isRecording = true;
      });
      // Mulai timer untuk menyimpan data otomatis tiap 5 detik
      _autoSaveTimer = Timer.periodic(Duration(seconds: 5), (timer) {
        _saveCurrentData();
      });
    } catch (e) {
      print(e);
    }
  }

  soundStream() => _noiseSubscription = _noiseMeter!.noiseStream.listen(onData);

  void stop() {
    _noiseSubscription?.cancel();
    _autoSaveTimer?.cancel();
    setState(() {
      _isRecording = false;
    });
  }

  void onData(NoiseReading noiseReading) {
    setState(() {
      _currentDecibel = noiseReading.meanDecibel;
      // Tambahkan data ke list untuk keperluan grafik
      _dataList.add(
        NoiseData(
          timestamp: DateTime.now(),
          decibel: noiseReading.meanDecibel,
        ),
      );
      // Batasi list untuk menampilkan data real-time (misalnya 20 data terakhir)
      if (_dataList.length > 20) {
        _dataList.removeAt(0);
      }
    });
  }

  Future<void> _saveCurrentData() async {
    // Simpan data terakhir yang diukur ke database
    if (_dataList.isNotEmpty) {
      NoiseData latest = _dataList.last;
      await _databaseHelper.insert(latest);
      print("Data saved: ${latest.timestamp} - ${latest.decibel} dB");
    }
  }

  // Fungsi untuk penyimpanan manual
  Future<void> _manualSave() async {
    await _saveCurrentData();
     ScaffoldMessenger.of(context as BuildContext).showSnackBar(
  SnackBar(content: Text("Pesan berhasil dikirim")),
    );
  }

  @override
  void dispose() {
    _noiseSubscription?.cancel();
    _autoSaveTimer?.cancel();
    super.dispose();
  }

  // Widget untuk menampilkan grafik real-time menggunakan fl_chart
  Widget _buildChart() {
    List<FlSpot> spots = [];
    for (int i = 0; i < _dataList.length; i++) {
      spots.add(FlSpot(i.toDouble(), _dataList[i].decibel));
    }
    return LineChart(
      LineChartData(
        minX: 0,
        maxX: (_dataList.length - 1).toDouble(),
        minY: 0,
        maxY: 120, // asumsi nilai maksimal kebisingan
        lineBarsData: [
          LineChartBarData(
            spots: spots,
            isCurved: true,
            colors: [Colors.blue],
            barWidth: 3,
            dotData: FlDotData(show: false),
          ),
        ],
        titlesData: FlTitlesData(
          bottomTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: false,
            ),
          ),
          leftTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              reservedSize: 40,
              interval: 20,
            ),
          ),
        ),
      ),
    );
  }

  // Tampilan halaman utama
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Sound Meter'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Text(
              'Current Noise Level: ${_currentDecibel.toStringAsFixed(2)} dB',
              style: TextStyle(fontSize: 24),
            ),
            SizedBox(height: 20),
            Expanded(child: _buildChart()),
            SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                ElevatedButton(
                  onPressed: _isRecording ? null : start,
                  child: Text('Mulai'),
                ),
                ElevatedButton(
                  onPressed: _isRecording ? stop : null,
                  child: Text('Berhenti'),
                ),
                ElevatedButton(
                  onPressed: _manualSave,
                  child: Text('Simpan Manual'),
                ),
              ],
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () async {
                // Navigasi ke halaman riwayat data
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => HistoryPage()),
                );
              },
              child: Text('Lihat Riwayat Data'),
            ),
          ],
        ),
      ),
    );
  }
}

AxisTitles({required SideTitles sideTitles}) {
}

/// Model data untuk penyimpanan data kebisingan
class NoiseData {
  final int? id;
  final DateTime timestamp;
  final double decibel;

  NoiseData({this.id, required this.timestamp, required this.decibel});

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'timestamp': timestamp.toIso8601String(),
      'decibel': decibel,
    };
  }

  factory NoiseData.fromMap(Map<String, dynamic> map) {
    return NoiseData(
      id: map['id'],
      timestamp: DateTime.parse(map['timestamp']),
      decibel: map['decibel'],
    );
  }
}

/// Kelas untuk mengelola database SQLite
class DatabaseHelper {
  static const _databaseName = "sound_meter.db";
  static const _databaseVersion = 1;

  static const table = 'noise';
  static const columnId = 'id';
  static const columnTimestamp = 'timestamp';
  static const columnDecibel = 'decibel';

  // Singleton pattern
  DatabaseHelper._privateConstructor();
  static final DatabaseHelper instance = DatabaseHelper._privateConstructor();

  static Database? _database;
  Future<Database> get database async =>
      _database ??= await _initDatabase();

  Future<Database> _initDatabase() async {
    Directory documentsDirectory = await getApplicationDocumentsDirectory();
    String path = join(documentsDirectory.path, _databaseName);
    return await openDatabase(path,
        version: _databaseVersion, onCreate: _onCreate);
  }

  Future _onCreate(Database db, int version) async {
    await db.execute('''
          CREATE TABLE $table (
            $columnId INTEGER PRIMARY KEY AUTOINCREMENT,
            $columnTimestamp TEXT NOT NULL,
            $columnDecibel REAL NOT NULL
          )
          ''');
  }

  // Method untuk memasukkan data
  Future<int> insert(NoiseData data) async {
    Database db = await database;
    return await db.insert(table, data.toMap());
  }

  // Method untuk mengambil semua data berdasarkan rentang waktu tertentu
  Future<List<NoiseData>> queryAll({DateTime? start, DateTime? end}) async {
    Database db = await database;
    String whereClause = "";
    List<dynamic> whereArgs = [];
    if (start != null && end != null) {
      whereClause = "$columnTimestamp BETWEEN ? AND ?";
      whereArgs = [start.toIso8601String(), end.toIso8601String()];
    }
    final List<Map<String, dynamic>> maps = await db.query(
      table,
      where: whereClause.isNotEmpty ? whereClause : null,
      whereArgs: whereArgs.isNotEmpty ? whereArgs : null,
      orderBy: "$columnTimestamp DESC",
    );

    return List.generate(maps.length, (i) {
      return NoiseData.fromMap(maps[i]);
    });
  }
}

/// Halaman untuk menampilkan riwayat data dalam bentuk tabel
class HistoryPage extends StatefulWidget {
  @override
  _HistoryPageState createState() => _HistoryPageState();
}

class _HistoryPageState extends State<HistoryPage> {
  DatabaseHelper _databaseHelper = DatabaseHelper.instance;
  List<NoiseData> _historyData = [];
  DateTime? _startDate;
  DateTime? _endDate;

  @override
  void initState() {
    super.initState();
    _loadHistory();
  }
  Future<void> _loadHistory() async {
    List<NoiseData> data = await _databaseHelper.queryAll(
      start: _startDate,
      end: _endDate,
    );
    setState(() {
      _historyData = data;
    });
  }
Future<void> _selectDateRange(BuildContext context) async {
  DateTimeRange? picked = await showDateRangePicker(
    context: context, // context yang benar adalah parameter dari metode build
    firstDate: DateTime(2020),
    lastDate: DateTime.now(),
  );
  if (picked != null) {
    setState(() {
      _startDate = picked.start;
      _endDate = picked.end;
    });
    await _loadHistory();
  }
}

Widget _buildList() {
  if (_historyData.isEmpty) {
    return Center(child: Text("Tidak ada data"));
  }
  return ListView.builder(
    itemCount: _historyData.length,
    itemBuilder: (context, index) {
      NoiseData data = _historyData[index];
      return ListTile(
        leading: Icon(Icons.volume_up),
        title: Text('${data.decibel.toStringAsFixed(2)} dB'),
        subtitle: Text('${data.timestamp}'),
      );
    },
  );
}

@override
Widget build(BuildContext context) {
  return Scaffold(
    appBar: AppBar(
      title: Text("Riwayat Data Kebisingan"),
      actions: [
        IconButton(
          icon: Icon(Icons.filter_list),
          onPressed: () => _selectDateRange(context), // Panggil fungsi dengan benar
        ),
      ],
    ),
    body: _buildList(),
  );
}
}